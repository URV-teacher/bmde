void screenshot(const char* filename);
void screenshotbmp(const char* filename);
